# -*- coding: utf-8 -*-
"""
Created on Sat Feb 02 11:25:45 2019
Masel Lab
Project: Mutation-driven Adaptation
@author: Kevin Gomez

Description:
Defines the basics functions used in all scripts that process matlab
data and create figures in the mutation-driven adaptation manuscript.
"""
# libraries
import numpy as np
import scipy.optimize as opt

# *****************************************************************************
# FUNCTIONS TO GET QUANTITIES FROM DESAI AND FISHER 2007
# *****************************************************************************


def get_vDF(N,s,U):
    # Calculates the rate of adaptation v, derived in Desai and Fisher 2007
    # for a given population size (N), selection coefficient (s) and beneficial
    # mutation rate (U)
    #
    # Inputs:
    # N - population size
    # s - selection coefficient
    # U - beneficial mutation rate
    #
    # Output: 
    # v - rate of adaptation
        
    v = s**2*(2*np.log(N*s)-np.log(s/U))/(np.log(s/U)**2)
    
    if np.isnan(v):
        return 0
    else:
        return v

# -----------------------------------------------------------------------------

def get_vDF_lnN_vers(lnN,s,U):
    # Calculates the rate of adaptation v, derived in Desai and Fisher 2007
    # for a given natural log of population size (lnN), selection coefficient (s) and beneficial
    # mutation rate (U)
    #
    # Inputs:
    # lnN - natural log of population size
    # s - selection coefficient
    # U - beneficial mutation rate
    #
    # Output: 
    # v - rate of adaptation
        
    v = s**2*(2*lnN + 2*np.log(s)-np.log(s/U))/(np.log(s/U)**2)
    
    if np.isnan(v):
        return 0
    else:
        return v

# -----------------------------------------------------------------------------

def get_vDF_pfix_vers(N,s,U,pfix):
    # Calculates the rate of adaptation v, derived in Desai and Fisher 2007
    # for a given natural log of population size (lnN), selection coefficient (s) and beneficial
    # mutation rate (U)
    #
    # Inputs:
    # lnN - natural log of population size
    # s - selection coefficient
    # U - beneficial mutation rate
    # pfix - numerically calcualted pfix value for class
    #
    # Output: 
    # v - rate of adaptation
        
    # need to split out into successional and multiple mutations regimes
    
    v = s**2*(2.0*np.log(N*pfix)-np.log(s/U))/(np.log(s/U)**2)
    
    if np.isnan(v):
        return 0
    else:
        return v
#------------------------------------------------------------------------------

def get_qDF(N,s,U):
    # Calculates the rate of adaptation v, derived in Desai and Fisher 2007
    # for a given population size (N), selection coefficient (s) and beneficial
    # mutation rate (U)
    #
    # Inputs:
    # N - population size
    # s - selection coefficient
    # U - beneficial mutation rate
    #
    # Output: 
    # v - rate of adaptation
        
    q = 2*np.log(N*s)/np.log(s/U)
    
    return q

#------------------------------------------------------------------------------
    
def get_death_terms_classes(b,do,sa):
    # function calculates the class for which population size has a negative 
    # growth rate in the Bertram & Masel 2019 lottery model
    #
    # inputs:
    # b - juvenile birth rate
    # do - death term of optimal genotype
    # sa - selection coefficient of beneficial mutations in "d" trait
    #
    # Output: 
    # di - set of death terms for absolute fitness classes
    # d_max - death term at which population is no longer viable
    # i_ext - smallest absolute fitness class with negative growth
    # 
    
    d_max = b + 2 
    di = [do]
    i_ext = 0
    
    while (di[-1] <= d_max):
        di = di+[di[-1]*(1+sa*(di[-1]-1))]
        i_ext = i_ext+1   
            
    di = np.asarray(di)
    return [di,i_ext,d_max]
#------------------------------------------------------------------------------

def get_mutation_rates_RunOutMutModel(UaMax,i_ext):
    # function calculates mutation rates for absolute fitness classes
    #
    # inputs:
    # UaMax - Maximum mutation rate at i_ext
    # i_ext - extinction class (last viable class)
    #
    # Output: 
    # Uai - set of death terms for absolute fitness classes
    #     
    
    Uai = np.zeros([i_ext+1]) 

    for i in range(0,i_ext+1):
        Uai[i] = UaMax*((1.0*i)/i_ext)
        
    return Uai

#------------------------------------------------------------------------------

def get_rate_env_change_scaled(R,di):
    # function calculates rate of environmental change scaled to match rates
    # of adaptation given in generation
    #
    # inputs:
    # R - Rate of environmental change (per unit of time for one iteration)
    # di - death term for class, which determines generation time of population
    #
    # Output: 
    # Ri - Rate of Env. change per generation (class i) 
    #     
    
    Ri = R/(di-1)
    
    return Ri

#------------------------------------------------------------------------------
    
def get_eq_pop_density(b,di,sa,option):
    # Calculate the equilibrium population size for the Bertram & Masel
    # variable density lottery model, single class case.
    #
    # Inputs:
    # b - juvenile birth rate
    # d - death rate
    # i - absolute fitness class (i beneficial mutations from optimal)
    # sa - absolute fitness selection coefficient
    #
    # Output: 
    # eq_density - equilibrium population density
    #
    # Remark: must have 1/sa*d > i >= 0 in general but for i = (1-d/(b+1))/sd
    # the population is in decline, unless it is rescued. Also, returns zero 
    # if formula gives negative density.
    
    def eq_popsize_err(y):    
        # used in numerical approach to obtain equilibrium population density
        return (1-y)*(1-np.exp(-b*y))-(di-1)*y

    if option == 1:
        # approximation near optimal gentotype
        eq_density = (1-np.exp(-b))/(di-np.exp(-b))+(di-1)/(di-np.exp(-b))*(np.exp(-b)-np.exp(-b*(1-np.exp(-b))/(di-np.exp(-b))))/(di-np.exp(-b*(1-np.exp(-b))/(di-np.exp(-b))))
        
        eq_density = np.max([eq_density,0]) # formula should 
        
    elif option == 2:
        # approximation near extinction genotype
        eq_density = (b+2)/(2*b)*(1-np.sqrt(1-8*(b-di+1)/(b+2)**2))
        
        eq_density = np.max([eq_density,0])
        
    else:
        # numerical solution to steady state population size equation
        eq_density = opt.broyden1(eq_popsize_err,[1], f_tol=1e-14)
        
        eq_density = np.max([eq_density,0])
        
    return eq_density

#------------------------------------------------------------------------------
    
def get_c_selection_coefficient(b,di,y,cr):
    # Calculate the "c" selection coefficient for the Bertram & Masel variable 
    # density lottery model for choice of ci = (1+sr)^i
    #
    # Inputs:
    # b - juvenile birth rate
    # di - death term associated with genotype
    # y - equilibrium population density (note that eff_sr has dependence on "d"
    # 	  through the equilibrium density as well).
    # cr - increase to ci from a single beneficial mutation is (1+sr)
    #
    # Output: 
    # eff_sr - selection coefficient of beneficial mutation in "c" trait
    #

    eff_r = cr*(1-y)*(1-(1+b*y)*np.exp(-b*y))/(y+(1-y)*(1-np.exp(-b)))*(b*y-1+np.exp(-b*y))/(b*y*(1-np.exp(-b*y))+cr*(1-(1+b*y)*np.exp(-b*y)))
    
    # scale growth rate to get growth rate per gen (1 gen = 1/(di-1) model iterations)
    eff_sr = eff_r/(di-1)
    
    if np.isnan(eff_sr):
        return 0
    else:
        return eff_sr



